# 从本包中的重要模块中导入
from .arraylib import *
from .treelib import *

# 定义需要自动导入的重要模块，方便开发者调用
__all__ = [
    #"deskcheck",
    "treenode",
]
