import algo
import stralgo
from algo import *
from stralgo import *
